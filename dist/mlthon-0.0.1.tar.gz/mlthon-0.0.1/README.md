# MLthon

## About

In this GitHub Repository, I have made many Machine learning Algorithms from scratch.

You can learn what is happening Under The Hood of all these Algorithms (or Mathematics)

## Installation

```
$ git clone https://github.com/pritishmishra703/MLthon.git
$ cd MLthon
$ python setup.py install
```

## Folder Structure

You will get all Linear Algorithms in `linreg.py`, all Data Preprocessing algorithms in `dataprocess.py`.

Note: This Repository is under construction and new Algorithms will be added soon. You can too contribute!
