import numpy as np

class DecisionTreeClassifier:

    def __init__(self):
        pass
